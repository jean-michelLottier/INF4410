############# README ####################

port=5000
mode=secure
frequencyFalseResults=20
1- Dans le fichier config réglé le mode et le port désiré (similaire à tous les 
serveurs). Seul le mode secure est opérationnel (explication dans README.txt du
dossier DISPATCHER). 

2- Lancer le jar dans le dossier dist pour lancer vos serveur. Lorqu'il vous
est demandé d'entrer un hôte saississez l'adresse IP ou l'host de la machine.
